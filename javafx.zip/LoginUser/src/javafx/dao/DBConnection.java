package javafx.dao;

import java.sql.*;
public class DBConnection {
	private DBConnection() {};
	private static Connection conn=null;
	public static Connection getConnection()
	{
		if(conn==null)
		{
        try
        {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            
            conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databasName=TutorialDB;username=sa;password=bhoolgaya;");
            System.out.println("Connection Successfully");
            
                    
         }
        catch (Exception e)
        {
            e.printStackTrace();
        }
		}
		return conn;
	}

}


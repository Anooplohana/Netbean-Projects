package javafx.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import application.Student;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import application.MainController;

public class DBManager {

	static Connection conn=MainController.conn;
	static PreparedStatement pst=null;
	public static Boolean getLogin(String uname, String pass) {
		Boolean check=false;
			try {
			String sql= "Select * from TutorialDB.dbo.login where username=? and password=?"; 
			pst=conn.prepareStatement(sql);
			pst.setString(1, uname);
			pst.setString(2, pass);
			ResultSet rst=pst.executeQuery();
			if(rst.next())
			{
				check=true;
			}
			} catch (SQLException e) {
				e.printStackTrace();
			}
				return check;
	}
	public static ResultSet getAllEmployees()
	{
		ResultSet rst=null;
		try {
			pst=conn.prepareStatement("Select * from TutorialDB.dbo.Employee");
			rst=pst.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rst;
		
	}
	public static int insertIntoEmployee(String uname)
	{
		int add=0;
		try {
			pst=conn.prepareStatement("Insert into TutorialDB.dbo.Employee(name) values(?)");
			pst.setString(1, uname);
			add=pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return add;
	}
	public static int deleteStudent(int id)
	{
		int delete=0;
		try {
			pst=conn.prepareStatement("Delete from TutorialDB.dbo.Student where s_id=?");
			pst.setInt(1, id);
			delete=pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
      return delete;
	}
	public static int insertRecord(Student student) {
		int add=0;
		try {
			pst=conn.prepareStatement("Insert into TutorialDB.dbo.Student\r\n" + 
					"values(?,?,?,?)\r\n" + 
					"");
			pst.setString(1, student.getName());
			pst.setString(2, student.getDepartment());
			pst.setString(3, student.getRollno());
			pst.setString(4, student.getContact());
			add=pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return add;
		
	}
	
	public static ObservableList<Student> getAllStudent()
	{
		 ObservableList<Student>sList=FXCollections.observableArrayList();

		try {
			pst=conn.prepareStatement("select * from TutorialDB.dbo.Student");
			ResultSet rst=pst.executeQuery();
			while(rst.next())
			{
				Student student=new Student();
				student.setId(rst.getInt("s_id"));
				student.setName(rst.getString("name"));
				student.setDepartment(rst.getString("department"));
				student.setRollno(rst.getString("rollno"));
				student.setContact(rst.getString("contact"));
				sList.add(student);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	   return sList;
	}
	public static int updateStudent(Student student) {
		int update=0;
		try {
			pst=conn.prepareStatement("\r\n" + 
					"update TutorialDB.dbo.Student set name=?,department=?,rollno=?,contact=? where s_id=?");
		pst.setString(1, student.getName());
		pst.setString(2, student.getDepartment());
		pst.setString(3, student.getRollno());
		pst.setString(4, student.getContact());
		pst.setInt(5, student.getId());
		update=pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return update;
	}
}

package application;

import javafx.scene.paint.Color;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.animation.Animation;
import javafx.animation.FadeTransition;
import javafx.animation.FillTransition;
import javafx.animation.ParallelTransition;
import javafx.animation.RotateTransition;
import javafx.animation.ScaleTransition;
import javafx.animation.SequentialTransition;
import javafx.animation.StrokeTransition;
import javafx.animation.TranslateTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.dao.DBConnection;
import javafx.dao.DBManager;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.AmbientLight;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class MainController implements Initializable {
    @FXML 
	private Label status;
	
    @FXML
    private TextField username;
    
    @FXML
    private PasswordField password;
    
	public static Connection conn;
	public static PreparedStatement pst;
	public void login(ActionEvent e)
	{
	   String uname=username.getText();
	   String pass=password.getText();
		Boolean check=DBManager.getLogin(uname,pass);
		if(check)
		{
			System.out.println("Successfully you login");
			try {
				
				Parent root=FXMLLoader.load(getClass().getResource("/application/Home.fxml"));
				Scene scene = new Scene(root);
				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				Main.primaryStage1.setScene(scene);
				
			} catch(Exception ex){
				ex.printStackTrace();
			}
			
		}
		else
		{

			Alert alert=new Alert(AlertType.ERROR);
			alert.setTitle("Authentication Problem");
			alert.setHeaderText("Oops! Incorrect Email or password");
		    alert.showAndWait();
		}
	 }
	
	@FXML
	Circle cir;
	@FXML
	Rectangle rect;
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		conn=DBConnection.getConnection();
		TranslateTransition transition=new TranslateTransition();
		ScaleTransition scale=new ScaleTransition(Duration.seconds(3),cir);
		FillTransition fillTransition=new FillTransition(Duration.seconds(3),cir,Color.CADETBLUE,Color.ANTIQUEWHITE);
		StrokeTransition strokeTransition=new StrokeTransition(Duration.seconds(3),cir,Color.CORAL,Color.BLUE);
		
	cir.setRadius(30);
	cir.setLayoutX(50);
	cir.setLayoutY(50);
	cir.setStroke(Color.CHOCOLATE);
	cir.setStrokeWidth(20);
	
	transition.setDuration(Duration.seconds(3));
	transition.setNode(cir);
	transition.setAutoReverse(true);
	transition.setToX(300);
	transition.setToY(300);
	transition.setCycleCount(Animation.INDEFINITE);
	transition.play();
	
	scale.setAutoReverse(false);
	scale.setCycleCount(Animation.INDEFINITE);
	scale.setToX(2);
	scale.setToY(2);
	scale.play();
	fillTransition.setAutoReverse(true);
	fillTransition.setCycleCount(Animation.INDEFINITE);
	fillTransition.play();
	
	strokeTransition.setAutoReverse(true);
	strokeTransition.setCycleCount(Animation.INDEFINITE);
	strokeTransition.play();
		
		rect=new Rectangle(300,300,100,100);
		rect.setArcHeight(50);
		rect.setArcWidth(50);
		rect.setFill(Color.VIOLET);
		
		final Duration SEC_2=Duration.millis(2000);
		final Duration SEC_3=Duration.millis(3000);
		
		FadeTransition ft=new FadeTransition(SEC_3);
		ft.setFromValue(1.0f);
		ft.setToValue(0.3f);
		ft.setCycleCount(2);
		ft.setAutoReverse(true);
	
		TranslateTransition tt=new TranslateTransition(SEC_2);
		tt.setAutoReverse(true);
		tt.setToX(100f);
		tt.setFromX(-100f);
		tt.setCycleCount(2);
		
		RotateTransition rt=new RotateTransition(SEC_3);
		rt.setByAngle(360);
		rt.setCycleCount(1);
		rt.setAutoReverse(true);
		
		ScaleTransition st=new ScaleTransition(SEC_2);
		st.setByX(1.5f);
		st.setByY(1.5f);
		st.setCycleCount(2);
		st.setAutoReverse(true);
		
		//ParallelTransition pt=new ParallelTransition(rect,ft,transition,tt,st);
		//pt.play();
		SequentialTransition stt=new SequentialTransition(rect,ft,tt,rt,st);
		stt.play();
	}

	
}

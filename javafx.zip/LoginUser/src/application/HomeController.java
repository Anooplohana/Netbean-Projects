package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.dao.DBManager;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;


public class HomeController implements Initializable {
	@FXML
	private Button update;
	@FXML
	private Button delete;
	
	//Components For SHowing the Record in Table
	@FXML
	private TableView<Student> table;
	@FXML
	private TableColumn<Student, Integer> sId;
	@FXML
	private TableColumn<Student, String> sName;
	@FXML
	private TableColumn<Student, String> sDepartment;
	@FXML
	private TableColumn<Student, String> sRollno;
	@FXML
	private TableColumn<Student, String> sContact;
	
	public ObservableList<Student>list;
   //Components For Adding Record
	@FXML
	private TextField name;
	@FXML
	private TextField department;
	@FXML
	private TextField rollno;
	@FXML
	private TextField contact;
	@FXML
	private Button add;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		 list=FXCollections.observableArrayList();
		   setCellTable();
		   loadDataFromDataBase();
			
	}
	private void setCellTable()
	{
		sId.setCellValueFactory(new PropertyValueFactory<Student,Integer>("id"));
		sName.setCellValueFactory(new PropertyValueFactory<Student,String>("name"));
		sDepartment.setCellValueFactory(new PropertyValueFactory<Student,String>("department"));
		sRollno.setCellValueFactory(new PropertyValueFactory<Student,String>("rollno"));
		sContact.setCellValueFactory(new PropertyValueFactory<Student,String>("contact"));
	}
	private void loadDataFromDataBase()
	{
		list=DBManager.getAllStudent();
		table.setItems(list);
	}
			//Adding the Record in DataBase
	public void addRecord(ActionEvent e)
	{
          Student student=new Student();
          student.setName(name.getText());
          student.setDepartment(department.getText());
          student.setRollno(rollno.getText());
          student.setContact(contact.getText());
          int add=DBManager.insertRecord(student);
          if(add!=0)
          {
        	Alert alert=new Alert(AlertType.INFORMATION);
  			alert.setTitle("Insertion");
  			alert.setHeaderText("Record Inserted Successfully");
  		    alert.showAndWait();
  		    afterOperatios();
          }
          else
          {
        	  Alert alert=new Alert(AlertType.ERROR);
  			alert.setTitle("Error");
  			alert.setHeaderText("Oops! Record Not Inserted");
  		    alert.showAndWait();
  	
          }
	}
	//SHowing the Record in TextFields
	int id;
	public void fillTextFields(MouseEvent e)
	{
		Student student=table.getSelectionModel().getSelectedItem();
		id=student.getId();
		name.setText(student.getName());
		department.setText(student.getDepartment());
		rollno.setText(student.getRollno());
		contact.setText(student.getContact());
		System.out.println(id);
	}
	
	public void updateRecord(ActionEvent e)
	{
		Student student=new Student();
		student.setId(id);
		student.setName(name.getText());
		student.setDepartment(department.getText());
		student.setRollno(rollno.getText());
		student.setContact(contact.getText());
		int update=DBManager.updateStudent(student);
		if(update!=0)
		{
			Alert alert=new Alert(AlertType.INFORMATION);
  			alert.setTitle("Updation");
  			alert.setHeaderText("Record Updated Successfully");
  		    alert.showAndWait();
  		    afterOperatios();
  		    
		}
		  else
          {
        	  Alert alert=new Alert(AlertType.ERROR);
  			alert.setTitle("Error");
  			alert.setHeaderText("Oops! Record Not Updated");
  		    alert.showAndWait();
  	
          }
	}
	
	//Deleting the Record
	public void deleteRecord(ActionEvent e)
	{
		int delete=DBManager.deleteStudent(id);
		if(delete!=0)
		{
		Alert alert=new Alert(AlertType.INFORMATION);
		alert.setTitle("Deletion");
		alert.setHeaderText("Record Deleted Successfully");
	    alert.showAndWait();
		afterOperatios();
		}
		else
		{
		Alert alert=new Alert(AlertType.ERROR);
		alert.setTitle("Error");
		alert.setHeaderText("Oops! Record Not Deleted");
	    alert.showAndWait();
		}
	}

    public void afterOperatios()
    {
			list=FXCollections.observableArrayList();
			setCellTable();
			loadDataFromDataBase();
			name.clear();
		    department.clear();
		    rollno.clear();
		    contact.clear();
		
    }
}



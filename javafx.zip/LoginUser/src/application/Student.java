package application;

public class Student {

	private Integer id;
	private String name;
	private String department;
	private String rollno;
	private String contact;

	
	public void setId(Integer id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public void setRollno(String rollno) {
		this.rollno = rollno;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public Integer getId() {
		return id;
	}

	public String getDepartment() {
		return department;
	}

	public String getRollno() {
		return rollno;
	}

	public String getContact() {
		return contact;
	}


	public String getName() {
		return name;
	}

	
}

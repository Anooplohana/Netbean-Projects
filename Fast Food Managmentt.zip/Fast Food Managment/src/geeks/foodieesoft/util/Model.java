/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.foodieesoft.util;

import geeks.foodieesoft.beans.Order;
import geeks.foodieesoft.beans.User;
import geeks.foodieesoft.dao.DBManager;
import geeks.foodieesoft.frames.UserForm;
import geeks.foodieesoft.frames.ViewFrame;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author hp
 */
public class Model {
  
   public Model()
   {
       
   }
   
    public static DefaultTableModel buildTableModel(ResultSet rs)
        throws SQLException {

    ResultSetMetaData metaData = rs.getMetaData();

    // names of columns
    Vector<String> columnNames = new Vector<String>();
    int columnCount = metaData.getColumnCount();
    for (int column = 1; column <= columnCount; column++) {
        columnNames.add(metaData.getColumnName(column));
    }

    // data of the table
    Vector<Vector<Object>> data = new Vector<Vector<Object>>();
    while (rs.next()) {
        Vector<Object> vector = new Vector<Object>();
        for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
            vector.add(rs.getObject(columnIndex));
        }
        data.add(vector);
    }

    return new DefaultTableModel(data, columnNames);

}
     public static DefaultTableModel addData() 
    {
         DefaultTableModel dft=null;
        try {
           dft=Model.buildTableModel(DBManager.getAllUsers());
            return dft;
        } catch (SQLException ex) {
            Logger.getLogger(UserForm.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dft;
    }
   
        public static DefaultTableModel addUserType()
        {
            DefaultTableModel dft=null;
        try {
           dft=Model.buildTableModel(DBManager.getUserTypes());
            return dft;
        } catch (SQLException ex) {
            Logger.getLogger(UserForm.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dft;
        }
         public static DefaultTableModel addUserCategory()
        {
            DefaultTableModel dft=null;
        try {
           dft=Model.buildTableModel(DBManager.getAllCategory());
           return dft;
        } catch (SQLException ex) {
            Logger.getLogger(UserForm.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dft;
        }
         public static DefaultTableModel addCustomerTable() 
         {
             DefaultTableModel dft=null;
       try {
           dft=Model.buildTableModel(DBManager.getAllCustomer());
           return dft;
       } catch (SQLException ex) {
           Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
       }
       return dft;
         }
         public static DefaultTableModel addQuestionTable()
         {
             DefaultTableModel dft=null;
       try {
           dft=buildTableModel(DBManager.getAllQuestion());
           return dft;
       } catch (SQLException ex) {
           Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
       }
       return dft;
         }
         public static DefaultTableModel addProductTable()
         {
             DefaultTableModel dft=null;
       try {
           dft=buildTableModel(DBManager.getAllProduct());
           return dft;
       } catch (SQLException ex) {
           Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
       }
       return dft;
         }
         public static DefaultTableModel addOrderTable()
         {
             DefaultTableModel dft=null;
       try {
           dft=buildTableModel(DBManager.getAllOrder());
           return dft;
       } catch (SQLException ex) {
           Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
       }
       return dft;
         }
         public static DefaultTableModel addCustomer()
         {
             DefaultTableModel dft=null;
       try {
           dft=buildTableModel(DBManager.getCustomer());
           return dft;
       } catch (SQLException ex) {
           Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
       }
       return dft;
         }
         public static DefaultTableModel addSales()
         {
             DefaultTableModel dft=null;
       try {
           dft=buildTableModel(DBManager.getSales());
           return dft;
       } catch (SQLException ex) {
           Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
       }
       return dft;
         }
         public static DefaultTableModel addViewOrder()
         {
             DefaultTableModel dft=null;
       try {
           dft=buildTableModel(DBManager.getViewOrder());
           return dft;
       } catch (SQLException ex) {
           Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
       }
       return dft;
         }
         
         /*public static DefaultTableModel addOrderDetail()
         {
             Order order=new Order();
             DefaultTableModel dft=null;
             ViewFrame viewFrame=new ViewFrame();
             ViewFrame.o
       try {
           dft=buildTableModel(DBManager.getOrderDetailTable(order));
           return dft;
       } catch (SQLException ex) {
           Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
       }
       return dft;
         }*/
         
}

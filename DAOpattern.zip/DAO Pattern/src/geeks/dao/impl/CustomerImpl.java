package geeks.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import geeks.dao.connection.DBConnection;
import geeks.dao.interfaces.CustomerDAO;
import geeks.dao.model.Customer;

public class CustomerImpl implements CustomerDAO {
	static Connection conn=DBConnection.getConnection();
    static PreparedStatement pst=null;

	@Override
	public List<Customer> getAllCustomer() {
	    List<Customer> listCustomer=new ArrayList<>(); 
		try {
			pst=conn.prepareStatement("Select name from customer");
			ResultSet rst=pst.executeQuery();
			while(rst.next())
			{
				Customer customer=new Customer();
				customer.setCustomeName(rst.getString("name"));
				listCustomer.add(customer);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listCustomer;
	}
     
}

package geeks.dao.interfaces;

import java.util.List;

import geeks.dao.model.Customer;

public interface CustomerDAO {
	public List<Customer> getAllCustomer();

}

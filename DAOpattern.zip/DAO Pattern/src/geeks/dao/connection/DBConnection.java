package geeks.dao.connection;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
	 private DBConnection() {};
	  private static Connection conn=null;
	  public static Connection getConnection()
	  {
		  if(conn==null)
		  {
			  try
			  {
				  System.out.println("Object Created");
				  Class.forName("com.mysql.jdbc.Driver");
				 conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/fast_food_managment","root","");
			  }catch(Exception e)
			  {
				  e.printStackTrace();
			  }
			  
		  }
		  return conn;
		  }
}

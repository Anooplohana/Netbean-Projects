package Main;

import java.util.List;

import geeks.dao.impl.CustomerImpl;
import geeks.dao.interfaces.CustomerDAO;
import geeks.dao.model.Customer;

public class Main {
	public static void main(String arg[])
	{
		CustomerDAO cInterfaces=new CustomerImpl();
		List<Customer> list=cInterfaces.getAllCustomer();
		for(Customer c: list)
		{
			System.out.println(c.getCustomeName());
		}
	}

}

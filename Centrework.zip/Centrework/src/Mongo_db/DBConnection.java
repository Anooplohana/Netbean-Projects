/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mongo_db;

import  
/**
 *
 * @author hp
 */
public class DBConnection {
    private DBConnection(){};
    private static MongoCredential credential=null;
    public static Connection getCOnnection()
    {
        if(conn==null)
        {
            Mongo
        
        return conn;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SQlite_Data_Base;

import centrework.Admin;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author hp
 */
public class DBManager {
    static Connection conn=DBConnection.getConnection1();
    static PreparedStatement pst=null;
    public static ResultSet login(Admin admin) throws SQLException
    {
        pst=conn.prepareStatement("Select * from admin where username=? and password=?");
        pst.setString(1, admin.getAdmin_name());
        pst.setString(2, admin.getAdmin_password());
        ResultSet rst=pst.executeQuery();
        return rst;
    }
}

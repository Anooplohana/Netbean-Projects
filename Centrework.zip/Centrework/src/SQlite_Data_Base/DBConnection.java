/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SQlite_Data_Base;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author hp
 */
public class DBConnection {
    private DBConnection(){};
    private static Connection conn=null;
    public static Connection getConnection1()
    {
        if(conn==null)
        {
        try{
            System.out.println("Object Created");
             Class.forName("org.sqlite.JDBC");
              conn=DriverManager.getConnection("jdbc:sqlite:C:\\sqlite2\\login.db");
             
        }catch(Exception e)
        {
            e.printStackTrace();
        }
        }
        return conn;
    }
    
}

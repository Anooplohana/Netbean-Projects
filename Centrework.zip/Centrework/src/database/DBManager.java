/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

/**
 *
 * @author hp
 */
import centrework.DDepartment;
import centrework.Department;
import centrework.Employee;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DBManager {
    
  static Connection conn=DBConnection.getConnection();
  static PreparedStatement pst=null;
  public static List<Department> getAllDepartments() throws SQLException
  {
      List<Department> department=new ArrayList<>();
      pst=conn.prepareStatement("Select * from department");
      ResultSet rst=pst.executeQuery();
      while(rst.next())
      {
          Department department1=new Department();
          department1.setName(rst.getString("dname"));
          department1.setId(rst.getInt("d_id"));
          department.add(department1);
      }
  return department;
  }
   
  public static Department getDepartmentWithName(String name) throws SQLException
  {
      Department department=new Department();
      pst=conn.prepareStatement("Select * from department where dname=?");
     pst.setString(1,name);
     ResultSet rst=pst.executeQuery();
     while(rst.next())
     
             {
                 department.setId(rst.getInt("d_id"));
                 department.setName(rst.getString("dname"));
                }
     return department;
  }
  public static ResultSet getAllDepartmentWithResultSet() throws SQLException
    {
        pst=conn.prepareStatement("Select from department");
        ResultSet rst=pst.executeQuery();   
       return rst; 
    }
  public static int addEmployee(Employee employee) throws SQLException
  {
      pst=null;
      int row=0;
      pst=conn.prepareStatement("Insert into employee(name,d_id) values(?,?)");
      pst.setString(1,employee.getEname());
      pst.setInt(2, employee.getDepartment().getId());
      row=pst.executeUpdate();
    return row; 
}
  
}

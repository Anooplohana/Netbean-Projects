/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package passwordencoder;

/**
 *
 * @author anoopkumar
 */
public class Check {
    public static void main(String arg[])
    {
        String brcode = "1-2-51";
        char  dash= '-';
        int count = 0;
        for(int i = 0; i<brcode.length();i++)
        {
            if(brcode.charAt(i)==dash)
            {
                count++;
            }
        }
        System.out.println("count: "+count);
                
        
    }
}

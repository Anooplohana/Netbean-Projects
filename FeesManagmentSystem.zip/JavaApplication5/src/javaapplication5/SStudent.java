/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication5;

/**
 *
 * @author hp
 */
public class SStudent {
    private int student_id;
    private String student_name;
    private String student_rollno;

    public String getStudent_rollno() {
        return student_rollno;
    }

    public void setStudent_rollno(String student_rollno) {
        this.student_rollno = student_rollno;
    }
  private String student_address;
  private DDepartment department;
  private BBatch batch;

    public int getStudent_id() {
        return student_id;
    }

    public void setStudent_id(int student_id) {
        this.student_id = student_id;
    }

    public String getStudent_name() {
        return student_name;
    }

    public void setStudent_name(String student_name) {
        this.student_name = student_name;
    }

    public String getStudent_address() {
        return student_address;
    }

    public void setStudent_address(String student_address) {
        this.student_address = student_address;
    }

    public DDepartment getDepartment() {
        return department;
    }

    public void setDepartment(DDepartment department) {
        this.department = department;
    }

    public BBatch getBatch() {
        return batch;
    }

    public void setBatch(BBatch batch) {
        this.batch = batch;
    }
  
    
}

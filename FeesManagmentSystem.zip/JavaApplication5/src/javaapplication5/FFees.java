/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication5;

/**
 *
 * @author hp
 */
public class FFees {
private int fees_id;
private String fees_date;
private BBatch batch;

    public int getFees_id() {
        return fees_id;
    }

    public void setFees_id(int fees_id) {
        this.fees_id = fees_id;
    }

    public String getFees_date() {
        return fees_date;
    }

    public void setFees_date(String fees_date) {
        this.fees_date = fees_date;
    }

    public BBatch getBatch() {
        return batch;
    }

    public void setBatch(BBatch batch) {
        this.batch = batch;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication5;

/**
 *
 * @author hp
 */
public class BBridge {
    private  int bridge_id;
    private SStudent student;
    private FFees fees;

    public int getBridge_id() {
        return bridge_id;
    }

    public void setBridge_id(int bridge_id) {
        this.bridge_id = bridge_id;
    }

    public SStudent getStudent() {
        return student;
    }

    public void setStudent(SStudent student) {
        this.student = student;
    }

    public FFees getFees() {
        return fees;
    }

    public void setFees(FFees fees) {
        this.fees = fees;
    }
    
}

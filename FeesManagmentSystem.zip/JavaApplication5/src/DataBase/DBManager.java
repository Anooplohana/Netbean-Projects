/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataBase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javaapplication5.BBatch;
import javaapplication5.BBridge;
import javaapplication5.DDepartment;
import javaapplication5.FFees;
import javaapplication5.SStudent;
import javaapplication5.Login;
import javax.swing.JOptionPane;

/**
 *
 * @author hp
 */
public class DBManager {
    static Connection conn=DBConnection.getConnection();
    static PreparedStatement pst=null;
    public static int login(Login login) throws SQLException
    {
        int row=0;
        pst=conn.prepareStatement("select * from admin where username=? && password=?");
        pst.setString(1, login.getUsername());
        pst.setString(2, login.getPassword());
        ResultSet rst=pst.executeQuery();
        if(rst.next())
        {
            row=1;
        }
        else
        {
          row=0;
        }
            
      return row;
    }
    public static int addDepartment(DDepartment dept) throws SQLException
    {
        pst=conn.prepareStatement("insert into department(d_name) values(?)");
        pst.setString(1,dept.getDep_name());
        int row=pst.executeUpdate();
        return row;
    }
    public static int updateDepartment(String oldname, DDepartment dept) throws SQLException
    {
        pst=conn.prepareStatement("Update department set d_name=? where d_name=?");
        pst.setString(1, dept.getDep_name());
        pst.setString(2, oldname);
        int row=pst.executeUpdate();
     return row;
    }
    public static int addBatch(BBatch batch) throws SQLException
    {
        pst=conn.prepareStatement("insert into batch(b_name) values(?)");
        pst.setString(1,batch.getBatch_name());
        int row=pst.executeUpdate();
        return row;
    }
    public static int updateBatch(String oldname, BBatch batch) throws SQLException
    {
        pst=conn.prepareStatement("Update batch set b_name=? where b_name=?");
        pst.setString(1, batch.getBatch_name());
        pst.setString(2, oldname);
        int row=pst.executeUpdate();
     return row;
    }
    public static List<DDepartment> getAllDepartments() throws SQLException
    {
        List<DDepartment> department=new ArrayList<>();
        pst=conn.prepareStatement("Select * from department");
        ResultSet rst=pst.executeQuery();
        while(rst.next())
        {
            DDepartment dept=new DDepartment();
            dept.setDept_id(rst.getInt("d_id"));
            dept.setDep_name(rst.getString("d_name"));
            department.add(dept);
        }
       return department; 
    }
    public static DDepartment getDepartmentWithName(String name) throws SQLException
    {
        DDepartment dept=new DDepartment();
        pst=conn.prepareStatement("select * from department where d_name=?");
        pst.setString(1, name);
        ResultSet rst=pst.executeQuery();
        while(rst.next())
        {
            dept.setDept_id(rst.getInt("d_id"));
            dept.setDep_name(rst.getString("d_name"));
            
        }
        return dept;
    }
   
    public static List<BBatch> getAllBatches() throws SQLException
    {
        List<BBatch> batch=new ArrayList<>();
        pst=conn.prepareStatement("Select * from batch");
        ResultSet rst=pst.executeQuery();
        while(rst.next())
        {
         BBatch bat=new BBatch();
         bat.setBatch_id(rst.getInt("b_id"));
         bat.setBatch_name(rst.getString("b_name"));
         batch.add(bat);
        }
    return batch;
}
    public static BBatch getBatchWithName(String name) throws SQLException
    {
        BBatch batch=new BBatch();
        pst=conn.prepareStatement("Select * from batch where b_name=?");
        pst.setString(1,name);
        ResultSet rst=pst.executeQuery();
        while(rst.next())
        {
            batch.setBatch_id(rst.getInt("b_id"));
            batch.setBatch_name(rst.getString("b_name"));
        }
    return batch;
    }
    public static int addStudent(SStudent student) throws SQLException
    {
        pst=conn.prepareStatement("Insert into student(st_name,st_rollno,st_address,d_id,b_id)values(?,?,?,?,?)");
        pst.setString(1,student.getStudent_name() );
        pst.setString(2, student.getStudent_rollno());
        pst.setString(3, student.getStudent_address());
        pst.setInt(4, student.getDepartment().getDept_id());
        pst.setInt(5, student.getBatch().getBatch_id());
        int row=pst.executeUpdate();
        return row;
    }
     public static int updateStudent(SStudent student,String rollNo) throws SQLException
    {
        pst=conn.prepareStatement("Update student set st_name=?,st_rollno=?,st_address=?,d_id=?,b_id=? where st_rollno=?");
        pst.setString(1, student.getStudent_name());
        pst.setString(2, student.getStudent_rollno());
        pst.setString(3, student.getStudent_address());
        pst.setInt(4, student.getDepartment().getDept_id());
        pst.setInt(5, student.getBatch().getBatch_id());
        pst.setString(6, rollNo);
        int row=pst.executeUpdate();
     return row;
    }
      public static int updateStudentAddress(String oldname, SStudent student) throws SQLException
    {
        pst=conn.prepareStatement("Update student set st_address=? where st_name=?");
        pst.setString(1, student.getStudent_address());
        pst.setString(2, oldname);
        int row=pst.executeUpdate();
     return row;
    }
       public static int updateStudentBatch(String oldrollno, SStudent student) throws SQLException
    {
        
        pst=conn.prepareStatement("Update student set b_id=? where st_rollno=?");
        pst.setInt(1, student.getBatch().getBatch_id());
        pst.setString(2, oldrollno);
        int row=pst.executeUpdate();
        
        return row;
    }
    public static List<SStudent> getALLStudents() throws SQLException
    {
        List<SStudent> listStudent=new ArrayList<>();
        pst=conn.prepareStatement("Select * from student");
         ResultSet rst=pst.executeQuery();
         while(rst.next())
         {
             SStudent student=new SStudent();
             BBatch batch=new BBatch();
             DDepartment department=new DDepartment();
             student.setStudent_name(rst.getString("st_name"));
             student.setStudent_rollno(rst.getString("st_rollno"));
             student.setStudent_address(rst.getString("st_address"));
             pst=conn.prepareStatement("Select * from department where d_id=?");
             pst.setInt(1, rst.getInt("d_id"));
             ResultSet rst1=pst.executeQuery();
             while(rst1.next())
             {
                 department.setDept_id(rst1.getInt("d_id"));
                 department.setDep_name(rst1.getString("d_name"));
             }
             System.out.println("abobe b_id");
             
             student.setDepartment(department);
             pst=conn.prepareStatement("Select * from batch where b_id=?");
             pst.setInt(1, rst.getInt("b_id"));
             System.out.println("below b_id");
             ResultSet rst2=pst.executeQuery();
             while(rst2.next())
             {
                 batch.setBatch_id(rst2.getInt("b_id"));
                 System.out.println("below loop");
                 batch.setBatch_name(rst2.getString("b_name"));
             }
             
             student.setBatch(batch);
             listStudent.add(student);
         }
        return listStudent;
    }
    public static BBatch currentBatch(String oldrollno) throws SQLException
    {
        BBatch batch=new BBatch();
        pst=conn.prepareStatement("Select b_id from student where st_rollno=?");
        pst.setString(1, oldrollno);
        ResultSet rst=pst.executeQuery();
        while(rst.next())
        {
            batch.setBatch_id(rst.getInt("b_id"));
        }
        pst=conn.prepareStatement("Select * from batch where b_id=?");
        pst.setInt(1, batch.getBatch_id());
         rst=pst.executeQuery();
         while(rst.next())
         {
             batch.setBatch_id(rst.getInt("b_id"));
             batch.setBatch_name(rst.getString("b_name"));
         }
        return batch;
    }
    public static SStudent getStudentWithRollNo(String rollno) throws SQLException
    {
        DDepartment department=new DDepartment();
        BBatch batch=new BBatch();
        SStudent student=new SStudent();
        int dept_id;
        int batch_id;
        pst=conn.prepareStatement("Select * from student where st_rollno=?");
        pst.setString(1, rollno);
        ResultSet rst=pst.executeQuery();
        while(rst.next())
        { 
            student.setStudent_name(rst.getString("st_name"));
            student.setStudent_rollno(rst.getString("st_rollno"));
            student.setStudent_address(rst.getString("st_address"));
            dept_id=rst.getInt("d_id");
            batch_id=rst.getInt("b_id");
            pst=conn.prepareStatement("Select * from department where d_id=?");
            pst.setInt(1, dept_id);
            ResultSet rst1=pst.executeQuery();
            while(rst1.next())
            {
                department.setDept_id(rst1.getInt("d_id"));
                department.setDep_name(rst1.getString("d_name"));
            }
            pst=conn.prepareStatement("Select * from batch where b_id=?");
            pst.setInt(1, batch_id);
            rst1=pst.executeQuery();
            while(rst1.next())
            {
                batch.setBatch_id(rst1.getInt("b_id"));
                batch.setBatch_name(rst1.getString("b_name"));
            }
            student.setDepartment(department);
            student.setBatch(batch);
        }
            return student;
        }
    public static List<SStudent> showStudentByDepartmentWise(DDepartment department) throws SQLException
    {
        List<SStudent> listStudent=new ArrayList<>();
        pst=conn.prepareStatement("select d_id from department where d_name=?");
        pst.setString(1, department.getDep_name());
        ResultSet rst=pst.executeQuery();
        while(rst.next())
        {
            department.setDept_id(rst.getInt("d_id"));
        }
        pst=conn.prepareStatement("Select * from student where d_id=?");
        pst.setInt(1, department.getDept_id());
         rst=pst.executeQuery();
        while(rst.next())
        {   BBatch batch=new BBatch();
            SStudent student=new SStudent();
            student.setStudent_name(rst.getString("st_name"));
            student.setStudent_rollno(rst.getString("st_rollno"));
            student.setStudent_address(rst.getString("st_address"));
            batch.setBatch_id(rst.getInt("b_id"));
            pst=conn.prepareStatement("Select b_name from batch where b_id=?");
            pst.setInt(1, batch.getBatch_id());
            ResultSet rst1=pst.executeQuery();
            while(rst1.next())
            {
                batch.setBatch_name(rst1.getString("b_name"));
            }
            student.setDepartment(department);
            student.setBatch(batch);
            listStudent.add(student);
        }
      return listStudent;
    }
     public static List<SStudent> showStudentByBatchWise(BBatch batch) throws SQLException
    {
        List<SStudent> listStudent=new ArrayList<>();
        pst=conn.prepareStatement("select b_id from batch where b_name=?");
        pst.setString(1, batch.getBatch_name());
        ResultSet rst=pst.executeQuery();
        while(rst.next())
        {
            batch.setBatch_id(rst.getInt("b_id"));
        }
        pst=conn.prepareStatement("Select * from student where b_id=?");
        pst.setInt(1, batch.getBatch_id());
         rst=pst.executeQuery();
        while(rst.next())
        {   DDepartment department=new DDepartment();
            SStudent student=new SStudent();
            student.setStudent_name(rst.getString("st_name"));
            student.setStudent_rollno(rst.getString("st_rollno"));
            student.setStudent_address(rst.getString("st_address"));
            department.setDept_id(rst.getInt("d_id"));
            pst=conn.prepareStatement("Select d_name from department where d_id=?");
            pst.setInt(1, department.getDept_id());
            ResultSet rst1=pst.executeQuery();
            while(rst1.next())
            {
               department.setDep_name(rst1.getString("d_name"));
            }
            student.setDepartment(department);
            student.setBatch(batch);
            listStudent.add(student);
        }
      return listStudent;
    }
        public static int addFess(FFees fees) throws SQLException
        {
         BBatch batch=new BBatch();
            pst=conn.prepareStatement("select b_id from batch where b_name=?");
            pst.setString(1, fees.getBatch().getBatch_name());
            ResultSet rst=pst.executeQuery();
            int b_id=0;
            while(rst.next())
            {
                batch.setBatch_id(rst.getInt("b_id"));
            }
            fees.setBatch(batch);
            pst=conn.prepareStatement("Insert into fees(b_id,fees_date) values(?,?)");
           pst.setInt(1, fees.getBatch().getBatch_id());
           pst.setString(2, fees.getFees_date());
           int row=pst.executeUpdate();
           return row;
           
        }
        public static BBatch feesBatchWithRollNo(SStudent student) throws SQLException
        {
            BBatch batch=new BBatch();
            
            pst=conn.prepareStatement("SELECT * FROM batch INNER JOIN student\r\n" + 
	  		"ON batch.`b_id`=student.`b_id`\r\n" + 
	  		"WHERE st_rollno=?");
            pst.setString(1, student.getStudent_rollno());
            ResultSet rst=pst.executeQuery();
            while(rst.next())
            {
                batch.setBatch_id(rst.getInt("b_id"));
                batch.setBatch_name(rst.getString("b_name"));
            }
            return batch;
        }
        public static List<FFees> feesDateWithRollNo(SStudent student) throws SQLException
        {
            List<FFees> listFees=new ArrayList<>();
            
            pst=conn.prepareStatement("SELECT * FROM fees INNER JOIN student \r\n" + 
	  		"ON fees.`b_id`=student.`b_id`\r\n" + 
	  		"WHERE student.`st_rollno`=?");
            pst.setString(1, student.getStudent_rollno());
            ResultSet rst=pst.executeQuery();
            while(rst.next())
            {
                FFees fees=new FFees();
             fees.setFees_date(rst.getString("fees_date"));
             listFees.add(fees);
            }
            return listFees;
        }
        public static int payFees(FFees fees, SStudent student) throws SQLException
        {
            pst=conn.prepareStatement("\r\n" + 
	  		"SELECT * FROM student INNER JOIN bridge\r\n" + 
	  		"ON student.`st_id`=bridge.`st_id`\r\n" + 
	  		"INNER JOIN fees\r\n" + 
	  		"ON fees.`fees_id`=bridge.`fees_id`\r\n" + 
	  		"WHERE fees.`fees_date`=? && st_rollno=?");
            pst.setString(1, fees.getFees_date());
            pst.setString(2, student.getStudent_rollno());
            ResultSet rst=pst.executeQuery();
            int row=0;
        if(rst.next())
        {
            row=2;
        }
        else
        {
            BBatch batch=new BBatch();
            BBridge bridge=new BBridge();
           pst=conn.prepareStatement("Select b_id,st_id from student WHERE st_rollno=?");
           pst.setString(1, student.getStudent_rollno());
           rst=pst.executeQuery();
           while(rst.next())
           {
               batch.setBatch_id(rst.getInt("b_id"));
               student.setStudent_id(rst.getInt("st_id"));
           }
           student.setBatch(batch);
           pst=conn.prepareStatement("Select fees_id from fees where b_id=? && fees_date=?");
           pst.setInt(1,student.getBatch().getBatch_id());
           pst.setString(2, fees.getFees_date());
           rst=pst.executeQuery();
           while(rst.next())
           {
               fees.setFees_id(rst.getInt("fees_id"));
           }
           bridge.setFees(fees);
           bridge.setStudent(student);
           pst=conn.prepareStatement("Insert into Bridge(fees_id,st_id)values(?,?)");
           pst.setInt(1,bridge.getFees().getFees_id());
           pst.setInt(2, bridge.getStudent().getStudent_id());
             row= pst.executeUpdate();
             
        }
       return row;
        }
        public static List<FFees> showFeesByRollNoPaid(SStudent student) throws SQLException
        {
            List<FFees> listFees=new ArrayList();
            
            pst=conn.prepareStatement("SELECT fees.`fees_date` FROM fees\n" +
            "INNER JOIN bridge ON\n" +
            "fees.`fees_id`=bridge.`fees_id`\n" +
            "INNER JOIN student ON\n" +
            "student.`st_id`=bridge.`st_id`\n" +
            "WHERE st_rollno=?");
            pst.setString(1, student.getStudent_rollno());
            System.out.println(student.getStudent_rollno());
            ResultSet rst=pst.executeQuery();
            while(rst.next())
            {
            FFees fees=new FFees();
            fees.setFees_date(rst.getString("fees_date"));
            System.out.println("fees object ");
            listFees.add(fees);
            }
            return listFees;
        }
        public static List<FFees> showFeesByRollNoNotPaid(SStudent student) throws SQLException
        {
             List<FFees> listFees=new ArrayList();
            
            pst=conn.prepareStatement("SELECT fees.`fees_date` FROM fees INNER JOIN batch \n" +
"      		ON fees.`b_id`=batch.`b_id` \n" +
"      		WHERE fees.`fees_id` NOT IN(SELECT bridge.`fees_id` FROM bridge INNER JOIN \n" +
"      		student ON\n" +
"      		bridge.`st_id`=student.`st_id` WHERE st_rollno=?) \n" +
"      		&& batch.`b_id`=(SELECT student.`b_id`FROM student WHERE st_rollno=?)");
            pst.setString(1, student.getStudent_rollno());
            pst.setString(2, student.getStudent_rollno());
            ResultSet rst=pst.executeQuery();
            while(rst.next())
            {
            FFees fees=new FFees();
            fees.setFees_date(rst.getString("fees_date"));
            listFees.add(fees);
            }
            return listFees;
            
        }

    public static ResultSet getViewOrder() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
        
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataBase;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author hp
 */
public class DBConnection {


   private DBConnection() {};
  private static Connection conn=null;
  public static Connection getConnection()
  {
	  if(conn==null)
	  {
		  try
		  {
			  System.out.println("Object Created");
			  Class.forName("com.mysql.jdbc.Driver");
			 conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/crud_system","root","");
		  }catch(Exception e)
		  {
			  e.printStackTrace();
		  }
	  }
	  return conn;
  }
}

    


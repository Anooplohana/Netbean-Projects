/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.foodieesoft.util;

/**
 *
 * @author Anoop
 */
import geeks.foodieesoft.dao.DBManager;
import java.io.ByteArrayOutputStream;
import java.util.Collection;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.eclipse.birt.core.exception.BirtException;
import org.eclipse.birt.core.framework.Platform;
import org.eclipse.birt.report.engine.api.EngineConfig;
import org.eclipse.birt.report.engine.api.EngineException;
import org.eclipse.birt.report.engine.api.HTMLRenderOption;
import org.eclipse.birt.report.engine.api.IReportEngine;
import org.eclipse.birt.report.engine.api.IReportEngineFactory;
import org.eclipse.birt.report.engine.api.IReportRunnable;
import org.eclipse.birt.report.engine.api.IRunAndRenderTask;

public class BirtEngine {
    IReportEngine engine=null;
	EngineConfig config = null;

public void takeReciept()
{
    
	{
                
		config = new EngineConfig( );			    
        try {
            //config.setLogConfig("c:/temp/test", Level.FINEST);
            Platform.startup(config);
        } catch (BirtException ex) {
            Logger.getLogger(BirtEngine.class.getName()).log(Level.SEVERE, null, ex);
        }
		IReportEngineFactory factory = (IReportEngineFactory) Platform
		.createFactoryObject( IReportEngineFactory.EXTENSION_REPORT_ENGINE_FACTORY );
		engine = factory.createReportEngine( config );		

		IReportRunnable design = null;
		//Open the report design
		String rpath = "C:\\Users\\Anoop\\workspace\\MyFirstReport/new_report.rptdesign"; 

        try { 
            design = engine.openReportDesign(rpath);
        } catch (EngineException ex) {
            Logger.getLogger(BirtEngine.class.getName()).log(Level.SEVERE, null, ex);
        }

		IRunAndRenderTask task = engine.createRunAndRenderTask(design); 		
		//task.setParameterValue("Top Count", (new Integer(5)));
		//task.validateParameters();
                int order=DBManager.getMaxOrder();
		HTMLRenderOption options = new HTMLRenderOption();		
		options.setOutputFileName("C:\\Users\\Anoop\\Desktop\\Reciepts/ReciptNo"+order+".docx");
		options.setOutputFormat("docx");
		//options.setHtmlRtLFlag(false);
		//options.setEmbeddable(false);
		//options.setImageDirectory("C:\\test\\images");

		//PDFRenderOption options = new PDFRenderOption();
		//options.setOutputFileName("c:/temp/test.pdf");
		//options.setOutputFormat("pdf");

		task.setRenderOption(options);
        try {
            task.run();
        } catch (EngineException ex) {
            Logger.getLogger(BirtEngine.class.getName()).log(Level.SEVERE, null, ex);
        }
		task.close();
		engine.destroy();
	  // final()
           {
	       Platform.shutdown( );
            }
        }
}
    
}

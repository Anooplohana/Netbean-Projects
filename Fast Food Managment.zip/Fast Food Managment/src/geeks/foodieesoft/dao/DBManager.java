/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geeks.foodieesoft.dao;
import java.util.ConcurrentModificationException;


import com.oracle.jrockit.jfr.Producer;
import geeks.foodieesoft.beans.Category;
import geeks.foodieesoft.beans.Customer;
import geeks.foodieesoft.beans.Order;
import geeks.foodieesoft.beans.OrderDetails;
import geeks.foodieesoft.beans.Permission;
import geeks.foodieesoft.beans.Product;
import geeks.foodieesoft.beans.Question;
import geeks.foodieesoft.beans.User;
import geeks.foodieesoft.beans.UserType;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author hp
 */
public class DBManager  {
    static Connection conn=DBConnection.getConnection();
    static PreparedStatement pst=null;
    public static String name;
    public static int id;
    public static User confirmLogin(User  user) throws SQLException
    {
       User newuser=new User();
        pst=conn.prepareStatement("Select * from user where binary username=? and binary password=? and activity_id=?");
        pst.setString(1, user.getUsername());
        pst.setString(2, user.getPassword());
        pst.setInt(3, 1);
        ResultSet rst=pst.executeQuery();
        if(rst.next())
        {
            newuser.setName(rst.getString("name"));
            newuser.setUserId(rst.getInt("user_id"));
            id=rst.getInt("user_id");
            name=rst.getString("name");
            System.out.println(id);
        return newuser;
        }
        else
        {
           newuser=null;
        }
        return newuser;
    }
    public static User showName(User user) throws SQLException
    {
        User user1=new User();
        pst=conn.prepareStatement("Select * from user where username=? and activity_id=?");
        pst.setString(1, user.getUsername());
        pst.setInt(2, 1);
        ResultSet rst=pst.executeQuery();
        while(rst.next()){
            user1.setName(rst.getString("name"));
            user1.setUserId(rst.getInt("user_id"));
        }
        return user1;
    }
    
    public static UserType getUserType(User user) throws SQLException
    {
        UserType userType=new UserType();
        pst=conn.prepareStatement("SELECT usertype.`type` FROM usertype INNER JOIN `user`\n" +
                                    "ON usertype.`user_type_id`=user.`user_type_id`\n" +
                                    "WHERE user.`name`=?");
              pst.setString(1, user.getName());
              ResultSet rst=pst.executeQuery();
              while(rst.next())
              {
                  userType.setType(rst.getString("type"));
              }
              return userType;

    }
    public static List<UserType> getAllUserTypes() throws SQLException
    {
        List<UserType> ListUser=new ArrayList<>();
        pst=conn.prepareStatement("Select * from usertype where activity_id=?");
        pst.setInt(1, 1);
        ResultSet rst=pst.executeQuery();
        while(rst.next())
        {
            UserType userType=new UserType();
            userType.setType(rst.getString("type"));
            ListUser.add(userType);
        }
        return ListUser;
    }    

    public static List<Question> getAllQuestions() throws SQLException
    {
        List<Question> listQuestion=new ArrayList<>();
        pst=conn.prepareStatement("Select question from question where activity_id=?");
        pst.setInt(1, 1);
        ResultSet rst=pst.executeQuery();
        while(rst.next())
        {
            Question question=new Question();
            question.setQuestion(rst.getString("question"));
            listQuestion.add(question);
        }
        return listQuestion;
    }
    public static int insertUser(User user) throws SQLException
    {
   
        pst=conn.prepareStatement("SELECT * FROM `user` WHERE user.`username`=? OR user.`contact`=?");
        pst.setString(1, user.getUsername());
        pst.setString(2, user.getContact());
        ResultSet rst1=pst.executeQuery();
        if(rst1.next()){
         return 0;   
        }
        else
        {
        UserType userType=new UserType();
        Question question=new Question();
        pst=conn.prepareStatement("Select user_type_id from usertype where type=? and activity_id=?");
        pst.setString(1, user.getUserType().getType());
        pst.setInt(2, 1);
        System.out.println("below setString state");
        ResultSet rst=pst.executeQuery();
        while(rst.next())       
        {
            userType.setUser_type_id(rst.getInt("user_type_id"));
        }
        user.setUserType(userType);
        
        pst=conn.prepareStatement("Select question_id from question where question=? and activity_id=?");
        pst.setString(1, user.getQuestion().getQuestion());
        pst.setInt(2, 1);
        rst=pst.executeQuery();
        while(rst.next())
        {
            question.setQuestion_id(rst.getInt("question_id"));
        }
        user.setQuestion(question);
        pst=conn.prepareStatement("Insert into user(user_type_id,username,password,name,contact,address,question_id,answer,created_by,created_date,modified_by,modified_date) values(?,?,?,?,?,?,?,?,?,?,?,?)");
        pst.setInt(1, user.getUserType().getUser_type_id());
        pst.setString(2, user.getUsername());
        pst.setString(3, user.getPassword());
        pst.setString(4, user.getName());
        pst.setString(5, user.getContact());
        pst.setString(6, user.getAddress());
        pst.setInt(7, user.getQuestion().getQuestion_id());
        pst.setString(8,user.getAnswer());
        pst.setInt(9, user.getCreatedBy());
        pst.setString(10, user.getCreatedDate());
        pst.setInt(11, user.getModifiedBy());
        pst.setString(12, user.getModifiedDate());
         int check=pst.executeUpdate();
        return check;
        }
     }
    public static ResultSet getAllUsers() throws SQLException
    {
        cArrayList.clear();
        mArrayList.clear();
        pst=conn.prepareStatement("SELECT username,TYPE,NAME,contact,address,question,answer,user.`created_by`,user.`created_date`,user.`modified_by`,user.`modified_date` \n" +
"FROM `user` INNER JOIN usertype\n" +
"                                    ON user.`user_type_id`=usertype.`user_type_id`\n" +
"                                    INNER JOIN question\n" +
"                                    ON user.`question_id`=question.`question_id`\n" +
"                                       WHERE user.activity_id=?");
        pst.setInt(1, 1);
        ResultSet rst=pst.executeQuery();
            while(rst.next())
        {
        cId=rst.getInt("created_by");
        mId=rst.getInt("modified_by");
        PreparedStatement pst1=conn.prepareStatement("SELECT username FROM `user` WHERE user_id=?");
        pst1.setInt(1, cId);
        ResultSet rst1=pst1.executeQuery();
        while(rst1.next())
        {
        cArrayList.add(rst1.getString("username"));
        System.out.println("Created= "+cArrayList.get(0));
        
        }
        pst1=conn.prepareStatement("SELECT username FROM `user` WHERE user_id=?");
        pst1.setInt(1, mId);
        rst1=pst1.executeQuery();
        while(rst1.next())
        {
        mArrayList.add(rst1.getString("username"));
        System.out.println("modified= "+mArrayList.get(0));
        }
        }
        rst=pst.executeQuery();
    
        return rst;
}
    public static int updateUser(User user,User user1) throws SQLException
    {
        UserType userType=new UserType();
        Question question=new Question();
        pst=conn.prepareStatement("Select user_type_id from usertype where type=? and activity_id=?");
        pst.setString(1, user.getUserType().getType());
        pst.setInt(2, 1);
        ResultSet rst=pst.executeQuery();
        while(rst.next())
        {
            userType.setUser_type_id(rst.getInt("user_type_id"));
            user.setUserType(userType);
        }
        pst=conn.prepareStatement("Select question_id from question where question=? and activity_id=?");
        pst.setString(1, user.getQuestion().getQuestion());
        pst.setInt(2, 1);
        rst=pst.executeQuery();
        while(rst.next())
        {
            question.setQuestion_id(rst.getInt("question_id"));
            user.setQuestion(question);
        }
        pst=conn.prepareStatement("Update user set username=?,user_type_id=?,name=?,contact=?,address=?,question_id=?,answer=?,modified_by=?,modified_date=? where username=?");
        pst.setString(1, user.getUsername());
        pst.setInt(2, user.getUserType().getUser_type_id());
        pst.setString(3, user.getName());
        pst.setString(4, user.getContact());
        pst.setString(5, user.getAddress());
        pst.setInt(6,user.getQuestion().getQuestion_id());
        pst.setString(7, user.getAnswer());
        pst.setInt(8, user.getModifiedBy());
        pst.setString(9, user.getModifiedDate());
        pst.setString(10, user1.getUsername());
        int update=pst.executeUpdate();
        return update;

    }
    public static int deleteUser(User user) throws SQLException
    {
        pst=conn.prepareStatement("Update user set activity_id=? where username=?");
        pst.setInt(1, 0);
        pst.setString(2, user.getUsername());
        int row=pst.executeUpdate();
        return row;
    }
    public static int addUserType(UserType userType) throws SQLException
    {
        pst=conn.prepareStatement("Insert into usertype(type,created_by,created_date,modified_by,modified_date) values(?,?,?,?,?)");
        pst.setString(1, userType.getType());
        pst.setInt(2, userType.getCreatedBy());
        pst.setString(3, userType.getCreatedDate());
        pst.setInt(4, userType.getModifiedBy());
        pst.setString(5, userType.getModifiedDate());
        int row=pst.executeUpdate();
        return row;
    }
    public static ResultSet getUserTypes() throws SQLException
    {
        cArrayList.clear();
        mArrayList.clear();
        pst=conn.prepareStatement("Select user_type_id,type,created_by,created_date,modified_by,modified_date from usertype where activity_id=1");
        ResultSet rst=pst.executeQuery();
            while(rst.next())
        {
        cId=rst.getInt("created_by");
        mId=rst.getInt("modified_by");
        PreparedStatement pst1=conn.prepareStatement("SELECT username FROM `user` WHERE user_id=?");
        pst1.setInt(1, cId);
        ResultSet rst1=pst1.executeQuery();
        while(rst1.next())
        {
        cArrayList.add(rst1.getString("username"));
        }
        pst1=conn.prepareStatement("SELECT username FROM `user` WHERE user_id=?");
        pst1.setInt(1, mId);
        rst1=pst1.executeQuery();
        while(rst1.next())
        {
        mArrayList.add(rst1.getString("username"));
        }
        }
        rst=pst.executeQuery();
    
        return rst;
    }
    public static int updateUserType(UserType userType) throws SQLException
    {
        pst=conn.prepareStatement("update usertype set type=?,modified_by=?,modified_date=? where user_type_id=?");
        pst.setString(1, userType.getType());
        pst.setInt(2, userType.getModifiedBy());
        pst.setString(3, userType.getModifiedDate());
        pst.setInt(4, userType.getUser_type_id());
        int row=pst.executeUpdate();
        return row;
    }
    public static int deleteUserType(UserType userType) throws SQLException
    {
        pst=conn.prepareStatement("Update usertype set activity_id=? where user_type_id=?");
        pst.setInt(1, 0);
        pst.setInt(2, userType.getUser_type_id());
        int row=pst.executeUpdate();
        return row;
    }
    public static int addCategory(Category category) throws SQLException
    {
        int row=0;
        pst=conn.prepareStatement("Select * from category where name=? and activity_id=1");
        pst.setString(1, category.getName());
        ResultSet rst=pst.executeQuery();
        if(rst.next())
        {
            row=0;
           }
        else
        {
        pst=conn.prepareStatement("Insert into category(name,created_by,created_date,modified_by,modified_date) values(?,?,?,?,?)");
        pst.setString(1, category.getName());
        pst.setInt(2, category.getCreatedBy());
        pst.setString(3,category.getCreatedDate());
        pst.setInt(4, category.getModifiedBy());
        pst.setString(5,category.getModifiedDate());
        row=pst.executeUpdate();
        }
        return row;
    }
    static int cId,mId;
    public static List<String> cArrayList=new ArrayList();
    public static List<String> mArrayList=new ArrayList();
    public static ResultSet getAllCategory() throws SQLException
    {
        cArrayList.clear();
        mArrayList.clear();
        pst=conn.prepareStatement("Select category_id,name,created_by,created_date,modified_by,modified_date from category where activity_id=1");
        ResultSet rst=pst.executeQuery();
        while(rst.next())
        {
        cId=rst.getInt("created_by");
        mId=rst.getInt("modified_by");
        PreparedStatement pst1=conn.prepareStatement("SELECT username FROM `user` WHERE user_id=?");
        pst1.setInt(1, cId);
        ResultSet rst1=pst1.executeQuery();
        while(rst1.next())
        {
        cArrayList.add(rst1.getString("username"));
        }
        pst1=conn.prepareStatement("SELECT username FROM `user` WHERE user_id=?");
        pst1.setInt(1, mId);
        rst1=pst1.executeQuery();
        while(rst1.next())
        {
        mArrayList.add(rst1.getString("username"));
        }
        }
        rst=pst.executeQuery();
        return rst;
    }
    public static int updateCategory(Category category) throws SQLException
    {
        int row=0;
        pst=conn.prepareStatement("Select * from category where name=? and activity_id=1");
        pst.setString(1, category.getName());
        ResultSet rst=pst.executeQuery();
        if(rst.next())
        {
            row=0;
         }
        else
        {
        
        pst=conn.prepareStatement("update category set name=?,modified_by=?,modified_date=? where category_id=? and activity_id=1");
        pst.setString(1, category.getName());
        pst.setInt(2, category.getModifiedBy());
        pst.setString(3, category.getModifiedDate());
        pst.setInt(4, category.getCategory_id());
        
         row=pst.executeUpdate();
        }
        return row;
    }
    public static int deleteCategory(Category category) throws SQLException
    {
        pst=conn.prepareStatement("Update category set activity_id=? where category_id=?");
        pst.setInt(1, 0);
        pst.setInt(2, category.getCategory_id());
        int row=pst.executeUpdate();
        return row;
    }
    public static int addCustomer(Customer customer) throws SQLException
    {
        int row=0;
        pst=conn.prepareStatement("Select * from customer where contact_no=? and activity_id=1 ");
        pst.setString(1, customer.getContact_no());
        ResultSet rst=pst.executeQuery();
        if(rst.next())
        {
            int active=rst.getInt("activity_id");
            if(active==1)
            {
            
               row=0; 
            }
            
        }
        else
        {
        pst=conn.prepareStatement("Insert into customer(name,contact_no,address,created_by,created_date,modified_by,modified_date)values(?,?,?,?,?,?,?)");
        pst.setString(1, customer.getName());
        pst.setString(2, customer.getContact_no());
        pst.setString(3, customer.getAddress());
        pst.setInt(4, customer.getCreatedBy());
        pst.setString(5, customer.getCreatedDate());
        pst.setInt(6, customer.getModifiedBy());
        pst.setString(7, customer.getModifiedDate());
        row=pst.executeUpdate();
        }
        return row;
     }
    public static ResultSet getAllCustomer() throws SQLException
    {
        cArrayList.clear();
        mArrayList.clear();
        pst=conn.prepareStatement("Select name,contact_no,address,created_by,created_date,modified_by,modified_date from customer where activity_id=?");
        pst.setInt(1, 1);
        ResultSet rst=pst.executeQuery();
        while(rst.next())
        {
        cId=rst.getInt("created_by");
        mId=rst.getInt("modified_by");
        PreparedStatement pst1=conn.prepareStatement("SELECT username FROM `user` WHERE user_id=?");
        pst1.setInt(1, cId);
        ResultSet rst1=pst1.executeQuery();
        while(rst1.next())
        {
        cArrayList.add(rst1.getString("username"));
        }
        pst1=conn.prepareStatement("SELECT username FROM `user` WHERE user_id=?");
        pst1.setInt(1, mId);
        rst1=pst1.executeQuery();
        while(rst1.next())
        {
        mArrayList.add(rst1.getString("username"));
        }
        }
        rst=pst.executeQuery();
        System.out.println(cArrayList);
        System.out.println(" "+mArrayList);
        
        return rst;
    }
    public static int updateCustomer(Customer customer,Customer customer1) throws SQLException
    {
        pst=conn.prepareStatement("update customer set name=?,contact_no=?,address=?,modified_by=?,modified_date=? where contact_no=?");
        pst.setString(1, customer.getName());
        pst.setString(2, customer.getContact_no());
        pst.setString(3, customer.getAddress());
        pst.setInt(4, customer.getModifiedBy());
        pst.setString(5, customer.getModifiedDate());
        pst.setString(6, customer1.getContact_no());
       
        int row=pst.executeUpdate();
      return row;
    }
    public static int deleteCustomer(Customer customer) throws SQLException
    {
        pst=conn.prepareStatement("Update customer set Activity_id=? where contact_no=?");
        pst.setInt(1, 0);
        pst.setString(2, customer.getContact_no());
        int row=pst.executeUpdate();
        return row;
    }
    public static int addQuestion(Question question) throws SQLException
    {
        pst=conn.prepareStatement("insert into question(question,created_by,created_date,modified_by,modified_date)values(?,?,?,?,?)");
        pst.setString(1, question.getQuestion());
        pst.setInt(2, question.getCreatedBy());
        pst.setString(3, question.getCreatedDate());
        pst.setInt(4, question.getModifiedBy());
        pst.setString(5, question.getModifiedDate());
       int add= pst.executeUpdate();
       return add;
        
    }
    public static ResultSet getAllQuestion() throws SQLException
    {
        cArrayList.clear();
        mArrayList.clear();
        pst=conn.prepareStatement("Select question_id,question,created_by,created_date,modified_by,modified_date from question where activity_id=?");
        pst.setInt(1, 1);
        ResultSet rst=pst.executeQuery();
         while(rst.next())
        {
        cId=rst.getInt("created_by");
        mId=rst.getInt("modified_by");
        PreparedStatement pst1=conn.prepareStatement("SELECT username FROM `user` WHERE user_id=?");
        pst1.setInt(1, cId);
        ResultSet rst1=pst1.executeQuery();
        while(rst1.next())
        {
        cArrayList.add(rst1.getString("username"));
        }
        pst1=conn.prepareStatement("SELECT username FROM `user` WHERE user_id=?");
        pst1.setInt(1, mId);
        rst1=pst1.executeQuery();
        while(rst1.next())
        {
        mArrayList.add(rst1.getString("username"));
        }
        }
        rst=pst.executeQuery();
       
        return rst;
        
    }
    public static int updateQuestion(Question question) throws SQLException
    {
        pst=conn.prepareStatement("Update question set question=?,modified_by=?,modified_date=? where question_id=?");
        pst.setString(1, question.getQuestion());
        pst.setInt(2, question.getModifiedBy());
        pst.setString(3, question.getModifiedDate());
        pst.setInt(4, question.getQuestion_id());
        int row=pst.executeUpdate();
        return row;
    }
    public static int deleteQuestion(Question question) throws SQLException
    {
        pst=conn.prepareStatement("Update question set activity_id=? where question_id=?");
        pst.setInt(1, 0);
        pst.setInt(2, question.getQuestion_id());
        int row=pst.executeUpdate();
        return row;
    }
    public static List<Category> getAllCategoryWithList() throws SQLException
    {
        List<Category> listCategory=new ArrayList<>();
        pst=conn.prepareStatement("Select name from category where activity_id=1");
        ResultSet rst=pst.executeQuery();
        while(rst.next())
        {
            Category category=new Category();
            category.setName(rst.getString("name"));
            listCategory.add(category);
        }
        return listCategory;
    }
    public static int addProduct(Product product) throws SQLException
    {
        Category category=new Category();
        pst=conn.prepareStatement("select category_id from category where name=?");
        pst.setString(1, product.getCategory().getName());
        ResultSet rst=pst.executeQuery();
        while(rst.next())
        {
            category.setCategory_id(rst.getInt("category_id"));
            
        }
        product.setCategory(category);
        pst=conn.prepareStatement("Insert into product(category_id,name,price,quantity,created_by,created_date,modified_by,modified_date) values(?,?,?,?,?,?,?,?)");
        pst.setInt(1, product.getCategory().getCategory_id());
        pst.setString(2, product.getName());
        pst.setInt(3, product.getPrice());
        pst.setInt(4, product.getQuantity());
        pst.setInt(5, product.getCreatedBy());
        pst.setString(6, product.getCreatedDate());
        pst.setInt(7, product.getModifiedBy());
        pst.setString(8, product.getModifiedDate());
        int row=pst.executeUpdate();
        return row;
    }
    public static ResultSet getAllProduct() throws SQLException
    {
        cArrayList.clear();
        mArrayList.clear();
        pst=conn.prepareStatement("SELECT category.`name`,product.`name`,product.`price`,`product`.`quantity`,\n" +
"   `product`.created_by,`product`.created_date,`product`.modified_by,\n" +
"   `product`.modified_date FROM product INNER JOIN category\n" +
"              ON product.`category_id`=`category`.`category_id`\n" +
"              WHERE product.`activity_id`=1");
        ResultSet rst=pst.executeQuery();
          while(rst.next())
        {
        cId=rst.getInt("created_by");
        mId=rst.getInt("modified_by");
        PreparedStatement pst1=conn.prepareStatement("SELECT username FROM `user` WHERE user_id=?");
        pst1.setInt(1, cId);
        ResultSet rst1=pst1.executeQuery();
        while(rst1.next())
        {
        cArrayList.add(rst1.getString("username"));
        }
        pst1=conn.prepareStatement("SELECT username FROM `user` WHERE user_id=?");
        pst1.setInt(1, mId);
        rst1=pst1.executeQuery();
        while(rst1.next())
        {
        mArrayList.add(rst1.getString("username"));
        }
        }
        rst=pst.executeQuery();
       
        return rst;
        
    }
    
    public static List<Product> getAllProductWithList() throws SQLException
    {
     List<Product> listProduct=new ArrayList<>();
        pst=conn.prepareStatement("SELECT `name`,price,quantity FROM product\n" +
                                    "WHERE activity_id=1");
        ResultSet rst=pst.executeQuery();
        int i=0;
        while(rst.next())
        {
            pst=conn.prepareStatement("SELECT category.`name` FROM category INNER JOIN product\n" +
                                        "ON category.`category_id`=product.`category_id`\n" +
                                        "WHERE `category`.`activity_id`=1 AND product.`name`=?");
            pst.setString(1, rst.getString("name"));
            Category category=null;
            
            ResultSet rst1=pst.executeQuery();
            while(rst1.next())
            {
            category=new Category();
            category.setName(rst1.getString("name"));
            System.out.println(i+++" "+category.getName());
            }
            
            Product product=new Product();
            product.setName(rst.getString("name"));
            product.setPrice(rst.getInt("price"));
            product.setQuantity(rst.getInt("quantity"));
            product.setCategory(category);
            listProduct.add(product);
        }
        //System.out.println(listProduct.size());
        return listProduct;
    }
    public static int updateProduct(Product product, Product product1 ) throws SQLException
    {
        pst=conn.prepareStatement("Select category_id from category where name=?");
        pst.setString(1, product.getCategory().getName());
        ResultSet rst=pst.executeQuery();
        Category category=new Category();
        while(rst.next())
        {
         category.setCategory_id(rst.getInt("category_id"));
        }
        product.setCategory(category);
        pst=conn.prepareStatement("update product set name=?,price=?,quantity=?,category_id=?,modified_by=?,modified_date=? where name=?");
        pst.setString(1, product.getName());
        pst.setInt(2, product.getPrice());
        pst.setInt(3, product.getQuantity());
        pst.setInt(4, product.getCategory().getCategory_id());
        pst.setInt(5, product.getModifiedBy());
        pst.setString(6, product.getModifiedDate());
        pst.setString(7,product1.getName());
        int row=pst.executeUpdate();
       return row;
    }
    public static int deleteProduct(Product product) throws SQLException
    {
        pst=conn.prepareStatement("update product set activity_id=? where name=?");
        pst.setInt(1, 0);
        pst.setString(2, product.getName());
        int row=pst.executeUpdate();
        return row;
    }
   
    public static ResultSet getAllOrder() throws SQLException
    {
        pst=conn.prepareStatement("SELECT `order`.`order_id`,`customer`.`name`,customer.`contact_no`,`order`.`date`,`order`.`order_no`\n" +
                                    "FROM customer INNER JOIN `order`\n" +
                                    "ON customer.`customer_id`=`order`.`customer_id`");
        ResultSet rst=pst.executeQuery();
        return rst;
    }
    public static ResultSet getCustomer() throws SQLException
    {
        pst=conn.prepareStatement("Select name,contact_no,address from customer where activity_id=1");
        ResultSet rst=pst.executeQuery();
        return rst;
    }
    public static ResultSet getSales() throws SQLException
    {
        pst=conn.prepareStatement("SELECT p.`name`,p.`price`,p.`quantity`,c.`name` FROM product p INNER JOIN category c\n" +
                                    "ON p.`category_id`=c.`category_id`\n" +
                                    "WHERE p.`activity_id`=1 AND c.`activity_id`=1;");
        ResultSet rst=pst.executeQuery();
        return rst;
    }
    public static Product getQuantity(Product product) throws SQLException
    {
        pst=conn.prepareStatement("Select quantity where name=?");
        pst.setString(1, product.getName());
        ResultSet rst=pst.executeQuery();
        while(rst.next()){
            product.setQuantity(rst.getInt("quantity"));
        }
                return product;
    }
    public static int updateQuantity(Product product) throws SQLException
    {
        pst=conn.prepareStatement("update product set quantity=? where name=? and activity_id=1");
        pst.setInt(1, product.getQuantity());
        pst.setString(2, product.getName());
        int update=pst.executeUpdate();
        return update;
    }
    public static Customer searchCustomer(Customer customer) throws SQLException
    {
       // Customer customerr=new Customer();
        pst=conn.prepareStatement("Select * from customer where contact_no=?");
        pst.setString(1, customer.getContact_no());
        ResultSet rst=pst.executeQuery();
        
        if(rst.next())
        {
            customer.setCustomer_id(rst.getInt("customer_id"));
            customer.setName(rst.getString("name"));
            customer.setContact_no(rst.getString("contact_no"));
            customer.setAddress(rst.getString("address"));
        }
        else
        {
            customer.setCustomer_id(0);
            customer.setName("null");
            customer.setContact_no("null");
            customer.setAddress("null");
        }
        return customer;
        
    }
    public static int addOrder(Order order) throws SQLException
    {
        int count;
        pst=conn.prepareStatement("Select * from `order` where order_no=?");
        System.out.println("1");
        pst.setInt(1, order.getOrder_no());
        System.out.println("2");
        ResultSet rst=pst.executeQuery();
        System.out.println("3");
        if(rst.next())
        {
            System.out.println("4");
            count=0;
        }
        else
        {
            System.out.println("5");
            if(order.getCustomer().getCustomer_id()!=0)
            {
            pst=conn.prepareStatement("Insert into `order`(date,customer_id,order_no,discount_type,discount_amount,bill)values(?,?,?,?,?,?)");
            pst.setString(1, order.getDate());   
            pst.setInt(2, order.getCustomer().getCustomer_id());
            pst.setInt(3, order.getOrder_no());
            pst.setString(4, order.getDiscountType());
            pst.setDouble(5, order.getDiscountAmount());
            pst.setInt(6, order.getBill());
            count=pst.executeUpdate();
            }
            else
            {
                pst=conn.prepareStatement("Insert into `order`(date,order_no,discount_type,discount_amount,bill)values(?,?,?,?,?)");
            pst.setString(1, order.getDate());
            pst.setInt(2, order.getOrder_no());
            pst.setString(3, order.getDiscountType());
            pst.setDouble(4, order.getDiscountAmount());
            pst.setInt(5, order.getBill());
            count=pst.executeUpdate();
            }
        }
        return count;
    }
    public static int addOrderDetail(Customer customer, OrderDetails orderDetails,Product product) throws SQLException
    {
        Order order=new Order();
        int add=0;
        if(customer.getCustomer_id()!=0)
        {
        pst=conn.prepareStatement("Select order_id from `order` where customer_id=? and activity_id=1");
        pst.setInt(1, customer.getCustomer_id());
       ResultSet rst= pst.executeQuery();
       while(rst.next())
        {
            order.setOrder_id(rst.getInt("order_id"));
            orderDetails.setOrder(order);
            System.out.println("got Order id");
        }
        pst=conn.prepareStatement("Select product_id from product where name=?");
        pst.setString(1, orderDetails.getProduct().getName());
        rst=pst.executeQuery();
        while(rst.next())
        {
           product.setProduct_id(rst.getInt("product_id"));
           orderDetails.setProduct(product);
           System.out.println(orderDetails.getProduct().getProduct_id()+" "+orderDetails.getProduct().getQuantity());
        }
        
        pst=conn.prepareStatement("Insert into `order details`(order_id,product_id,quantity)values(?,?,?)");
        pst.setInt(1, orderDetails.getOrder().getOrder_id());
        pst.setInt(2, orderDetails.getProduct().getProduct_id());
        pst.setInt(3, orderDetails.getQuantity());
         add=pst.executeUpdate();
       //return add;
        }
        else
        {
            add=0;
            System.out.println("Walkin Customer");
        }
        return add;
    }
    public static int addOrderDetail(Customer customer, OrderDetails orderDetails) throws SQLException
    {
        Order order=new Order();
         ResultSet rst;
     if(customer.getCustomer_id()!=0)
     {
        pst=conn.prepareStatement("Select order_id from `order` where customer_id=? and activity_id=1");
        pst.setInt(1, customer.getCustomer_id());
       rst= pst.executeQuery();
       while(rst.next())
        {
            order.setOrder_id(rst.getInt("order_id"));
            orderDetails.setOrder(order);
            System.out.println("got Order id");
        }
     }
     else
     {
         pst=conn.prepareStatement("SELECT `order_id` FROM `order` WHERE customer_id IS NULL and activity_id=1");
         rst= pst.executeQuery();
       while(rst.next())
        {
            order.setOrder_id(rst.getInt("order_id"));
            orderDetails.setOrder(order);
            System.out.println("got Order id");
        }
     }
        pst=conn.prepareStatement("Select product_id from product where name=?");
        pst.setString(1, orderDetails.getProduct().getName());
        rst=pst.executeQuery();
        while(rst.next())
        {
            Product product=new Product();
           product.setProduct_id(rst.getInt("product_id"));
           orderDetails.setProduct(product);
           System.out.println(orderDetails.getProduct().getProduct_id()+" "+orderDetails.getProduct().getQuantity());
        }
        
        pst=conn.prepareStatement("Insert into `order details`(order_id,product_id,quantity)values(?,?,?)");
        pst.setInt(1, orderDetails.getOrder().getOrder_id());
        pst.setInt(2, orderDetails.getProduct().getProduct_id());
        pst.setInt(3, orderDetails.getQuantity());
        int add=pst.executeUpdate();
       return add;
        
    }
      public static ResultSet getViewOrder() throws SQLException
      {
          pst=conn.prepareStatement("SELECT o.`order_no`,o.`date`,c.`name`,o.`Bill` FROM `order` o \n" +
                                    "INNER JOIN customer c \n" +
                                    "ON o.`customer_id`=c.`customer_id`");
          ResultSet rst=pst.executeQuery();
          return rst;
      }
      public static Order getOrderWithDiscountDetail(Order order) throws SQLException
      {
          pst=conn.prepareStatement("SELECT discount_type,discount_amount FROM `order` WHERE order_no=?");
          pst.setInt(1, order.getOrder_no());
          ResultSet rst=pst.executeQuery();
          while(rst.next())
          {
            order.setDiscountType(rst.getString("discount_type"));
            order.setDiscountAmount(rst.getInt("discount_amount"));
          }
          return order;
          
      }
      public static List<Order> getViewOrderWithWalkin() throws SQLException
      {
          List<Order> list=new ArrayList<>();
          pst=conn.prepareStatement("      \n" +
                                    "SELECT o.`order_no`,o.`date`,o.`customer_id`,o.`Bill` FROM `order` o \n" +
                                    " WHERE o.`customer_id` IS NULL");
         ResultSet rst=pst.executeQuery();
         while(rst.next())
         {
             Customer customer=new Customer();
             customer.setName("Walkin");
             Order order=new Order();
             order.setOrder_no(rst.getInt("order_no"));
             order.setDate(rst.getString("date"));
             order.setCustomer(customer);
             order.setBill(rst.getInt("Bill"));
             list.add(order);
         }
         return list;
      
      }
        public static List<User> getUsers() throws SQLException
        {
            List<User> arrayList = new ArrayList<>();
            
            pst=conn.prepareStatement("Select username from user");
            ResultSet rst=pst.executeQuery();
            while(rst.next())
            {
              User user=new User();
              user.setUsername(rst.getString("username"));
              arrayList.add(user);
            }
            return arrayList;
        }
        public static List<Permission> getAssignPermissions(User user) throws SQLException
        {
            List<Permission> list=new ArrayList<>();
            pst=conn.prepareStatement("SELECT permission.`name` FROM user_permission INNER JOIN `user`\n" +
                                        "ON user_permission.`user_id`=user.`user_id` \n" +
                                        "INNER JOIN permission\n" +
                                        "ON permission.`permission_id`=user_permission.`permission_id`\n" +
                                        "WHERE user.`username`=?");
            pst.setString(1, user.getUsername());
        ResultSet rst=pst.executeQuery();
        while(rst.next())
        {
            Permission permission=new Permission();
            permission.setName(rst.getString("name"));
            list.add(permission);
        }
        return list;
        }
        public static List<Permission> getUnAssignPermission(User user) throws SQLException 
        {
            List<Permission> listPermission=new ArrayList<>();
            pst=conn.prepareStatement(" SELECT `name` FROM permission WHERE permission_id NOT IN (SELECT permission_id FROM user_permission WHERE user_id=(SELECT user_id FROM `user` WHERE username=?))");
            pst.setString(1,user.getUsername());
            ResultSet rst=pst.executeQuery();
            while(rst.next())
            {
                Permission permission=new Permission();
                permission.setName(rst.getString("name"));
                listPermission.add(permission);
        
            }
           
            return listPermission;
        }
        public static int insertAssignPermissions(List<Permission> listPermission,User user) throws SQLException
        {
            int update=0;
            for(Permission p: listPermission)
                System.out.println(p.getName());
            pst=conn.prepareStatement("Select user_id from user where username=?");
            pst.setString(1, user.getUsername());
            ResultSet rst=pst.executeQuery();
            while(rst.next())
            {
                user.setUserId(rst.getInt("user_id"));
            } 
            
            List<Permission> list=new ArrayList<>();
            for(int i=0;i<listPermission.size();i++)
            {
            pst=conn.prepareStatement("Select permission_id from permission where name=?");
            pst.setString(1, listPermission.get(i).getName());
            rst=pst.executeQuery();
            while(rst.next())
            {
                
                Permission permission=new Permission();
                permission.setPermission_id(rst.getInt("permission_id"));
                System.out.println("idd= "+permission.getPermission_id());
                PreparedStatement pst1=conn.prepareStatement("SELECT * FROM user_permission\n" +
                                        "WHERE user_id=? AND permission_id=?");
                pst1.setInt(1, user.getUserId());
                pst1.setInt(2, permission.getPermission_id());
                ResultSet rst1=pst1.executeQuery();
                if(rst1.next())
                {
                    
                }
                else
                {
                    System.out.print("ids= "+permission.getPermission_id());
                     pst=conn.prepareStatement("INSERT INTO user_permission VALUES(?,?)");
                    pst.setInt(1, user.getUserId());
                    pst.setInt(2, permission.getPermission_id());
                    //System.out.println(pst);
                     update=pst.executeUpdate();
                    System.out.println("RECORD ADDED Succesfully");
                  }
              
            }
            }
            return update;
        }
      
        public static int removeAssignPermission(List<Permission> listPermission, User user) throws SQLException
        {
            List<Permission> list=new ArrayList<>();
             pst=conn.prepareStatement("Select user_id from user where username=?");
            pst.setString(1, user.getUsername());
            ResultSet rst=pst.executeQuery();
            while(rst.next())
            {
                user.setUserId(rst.getInt("user_id"));
            }
             int delete=0;
            for(int i=0;i<listPermission.size();i++)
            {
            pst=conn.prepareStatement("Select permission_id from permission where name=?");
            pst.setString(1, listPermission.get(i).getName());
        
            rst=pst.executeQuery();
            while(rst.next())
            {
                /*Permission permission=new Permission();
                permission.setPermission_id(rst.getInt("permission_id"));
                System.out.println("id= "+permission.getPermission_id());
                list.add(permission);
            }
            }
            System.out.println("size= "+list.size());
            System.out.println("idd= "+list.get(0).getPermission_id());
        
             for(int i=0;i<list.size();i++)
            {
            pst=conn.prepareStatement("DELETE FROM user_permission WHERE user_id=? AND permission_id=?");
            pst.setInt(1, user.getUserId());
            pst.setInt(2, list.get(i).getPermission_id());
            System.out.println(pst);
            delete=pst.executeUpdate();
            System.out.println("RECORD Deleted Succesfully");
            }*/
                   Permission permission=new Permission();
                permission.setPermission_id(rst.getInt("permission_id"));
                System.out.println("idd= "+permission.getPermission_id());
                PreparedStatement pst1=conn.prepareStatement("SELECT * FROM user_permission\n" +
                                        "WHERE user_id=? AND permission_id=?");
                pst1.setInt(1, user.getUserId());
                pst1.setInt(2, permission.getPermission_id());
                ResultSet rst1=pst1.executeQuery();
                if(rst1.next())
                {
                    System.out.print("ids= "+permission.getPermission_id());
                     pst=conn.prepareStatement("DELETE FROM user_permission WHERE \n" +
                                                "user_id=? AND permission_id=?");
                    pst.setInt(1, user.getUserId());
                    pst.setInt(2, permission.getPermission_id());
                     delete=pst.executeUpdate();
                    System.out.println("RECORD Deleted Succesfully");
  
                }
                
            }
            }
            return delete;
        }
        public static List<OrderDetails> getOrderDetailTable(Order order) throws SQLException
        {
            List<OrderDetails> listDetails=new ArrayList<>();
            pst=conn.prepareStatement("Select order_id from `order` where order_no=?");
            pst.setInt(1, order.getOrder_no());
            ResultSet rst=pst.executeQuery();
            while(rst.next())
            {
                order.setOrder_id(rst.getInt("order_id"));
                
            }
            System.out.println(order.getOrder_id());
            pst=conn.prepareStatement("SELECT product.`name`,`order details`.`quantity`,product.`price` FROM product\n" +
                                        "INNER JOIN `order details` ON product.`product_id`=`order details`.`product_id` \n" +
                                        "WHERE `order details`.`order_id`=?");
            pst.setInt(1, order.getOrder_id());
            rst=pst.executeQuery();
            while(rst.next())
            {
                OrderDetails orderDetails=new OrderDetails();
                Product product=new Product();
                product.setName(rst.getString("name"));
                orderDetails.setQuantity(rst.getInt("quantity"));
                 product.setPrice(rst.getInt("price"));
                orderDetails.setProduct(product);
                listDetails.add(orderDetails);
            }
            return listDetails;
        }
        public static List<Order> searchByDate(Order startDate,Order endDate) throws SQLException
        {
            List<Order> list=new ArrayList<>();
            pst=conn.prepareStatement("SELECT  o.`order_no`,o.`date`,c.`name`,o.`Bill` FROM `order` o INNER JOIN customer c\n" +
                                        "ON `o`.`customer_id`=c.`customer_id`\n" +
                                        "WHERE `date` BETWEEN ? AND ? ");
            pst.setString(1, startDate.getDate());
            pst.setString(2, endDate.getDate());
            ResultSet rst=pst.executeQuery();
            while(rst.next())
            {
                Customer customer=new Customer();
                Order order=new Order();
                order.setOrder_no(rst.getInt("order_no"));
                order.setDate(rst.getString("date"));
                customer.setName(rst.getString("name"));
                order.setCustomer(customer);
                order.setBill(rst.getInt("Bill"));
                list.add(order);
            }
            return list;
            
        }
        public static List<Order> searchByDateForWalkin(Order startDate,Order endDate) throws SQLException
        {
            List<Order> list=new ArrayList<>();
            pst=conn.prepareStatement("SELECT  o.`order_no`,o.`date`,o.`Bill` FROM `order` o \n" +
                         "WHERE `date` BETWEEN ? AND ? AND o.`customer_id` IS NULL");
            pst.setString(1, startDate.getDate());
            pst.setString(2, endDate.getDate());
            ResultSet rst=pst.executeQuery();
            while(rst.next())
            {
                Customer customer=new Customer();
                Order order=new Order();
                
                order.setOrder_no(rst.getInt("order_no"));
                //System.out.println("DataBase="+order.get)
                order.setDate(rst.getString("date"));
                customer.setName("walkin");
                order.setCustomer(customer);
                order.setBill(rst.getInt("Bill"));
                list.add(order);
            }
            return list;
        }
        
        public static User searchUser(User user) throws SQLException
        {
            pst=conn.prepareStatement("SELECT `name` FROM USER WHERE contact=?");
            pst.setString(1, user.getContact());
            ResultSet rst=pst.executeQuery();
            if(rst.next())
            {
                user.setName(rst.getString("name"));
            }
            else
                user.setName("");
            return user;
        }
        public static Boolean ConfirmUser(User user) throws SQLException
        {
            pst=conn.prepareStatement("SELECT * FROM `user` INNER JOIN question\n" +
                                    "ON `user`.`question_id`=question.`question_id`\n" +
                                    "WHERE `user`.`answer`=? AND `user`.`contact`=? AND question.`question`=? ");
             pst.setString(1, user.getAnswer());
             pst.setString(2,user.getContact());
             pst.setString(3, user.getQuestion().getQuestion());
            ResultSet rst=pst.executeQuery();
            Boolean confirm=false;
            if(rst.next())
                confirm=true;
            
            return confirm;
        }
        public static int addNewPassword(User user) throws SQLException
        {
            pst=conn.prepareStatement("UPDATE `user` SET `password`=? WHERE `contact`=?");
            pst.setString(1, user.getPassword());
            pst.setString(2, user.getContact());
            int update=pst.executeUpdate();
            return update;
        }

    public static int getMaxOrder() {
        int orderNo=0;
        try {
            pst=conn.prepareStatement("SELECT order_no FROM `order`\n" +
                                "WHERE `order_id`=(SELECT MAX(order_id) FROM `order`)");
            ResultSet rst=pst.executeQuery();
            while(rst.next())
            {
                orderNo=rst.getInt("order_no");
            }
        } catch (SQLException ex) {
            Logger.getLogger(DBManager.class.getName()).log(Level.SEVERE, null, ex);
        }
       return orderNo;    
    }
        
}